<?php
// Variables
$hostDB = '127.0.0.1';
$nombreDB = 'web'; 
$usuarioDB = 'root';
$contrasenyaDB = '1234567890';
// Conecta con base de datos
$hostPDO = "mysql:host=$hostDB;dbname=$nombreDB;"; 
$miPDO = new PDO($hostPDO, $usuarioDB, $contrasenyaDB);
// Prepara SELECT
$miConsulta = $miPDO->prepare('SELECT * FROM productos;');

// Ejecuta consulta
$miConsulta->execute();
?>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Velvet Vanity</title>
    <link rel="stylesheet" type="text/css" href="css/headfoot.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <header>
        <h1>Velvet Vanity</h1>
        <nav>
            <ul>
                <li><a href="paginasSecundarias/EncontrarUnaTienda.html" target="_blank">Encontrar una Tienda</a></li>
                <li><a href="paginasSecundarias/contacto.html" target="_blank">Contacto</a></li>
                <li><a href="paginasSecundarias/quines_somos.html" target="_blank">Quines somos</a></li>
                <li><a href="login_ab/login.php">Iniciar Sesión</a></li>
                <li><a href="login_ab/logout.php">Cerrar Sesión</a></li>
                <li><a href="paginasSecundarias/AtencionAlCliente.html" target="_blank">Atención al cliente</a></li>
            </ul>
        </nav>
        
    </header>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Velvet Vanity</title>
    <link rel="stylesheet" href="style.css">
</head>

<script>
    document.addEventListener('DOMContentLoaded', function () {
      var cartContainer = document.querySelector('.cart-items-container');
      var cartButton = document.getElementById('cart-btn');
      }
  
      cartButton.addEventListener('click', function () {
        cartContainer.classList.toggle('show');
      });
  
      var removeButtons = document.querySelectorAll('.cart-item .fa-times');
  
      removeButtons.forEach(function (button) {
        button.addEventListener('click', function () {
          button.parentElement.remove();
        });
      });
  
      var addToCartButtons = document.querySelectorAll('.box .btn');
      addToCartButtons.forEach(function (button) {
        button.addEventListener('click', function () {
          var box = button.closest('.box');
          var itemName = box.querySelector('h3').innerText;
          var itemPrice = box.querySelector('.price').innerText;
  
          var cartItem = document.createElement('div');
          cartItem.classList.add('cart-item');
          cartItem.innerHTML = `
            <span class="fas fa-times"></span>
            <img src="${box.querySelector('img').src}" alt="${itemName}">
            <div class="content">
              <h3>${itemName}</h3>
              <div class="price">${itemPrice}</div>
            </div>
          `;
  
          cartContainer.appendChild(cartItem);
        });
      });
    });
  </script>
    <body>
        
    <header>
        <div class="Tu tienda de maquillaje">
                <div class="textomoverse">
                    <h1 id="titulomov">Tu tienda de maquillaje</h1>
                    <p id="textomov">¡Hazte cliente y consigue envios gratis!</p>
                    <a href="#">Comprar ahora</a>
                </div>
            </div>
        </header>
        <main>
            <!--a partir de aqui comienza el contenido principal-->
            <section class="futbalrun">
                <article>
                    <img src="https://www.druni.es/blog/wp-content/uploads/2022/03/portada-39-800x427.jpg" alt="">
                    <h2>Rostro</h2>
                    <a href="tienda.html">comprar ahora</a>
                </article>
                <article>
                    <img src="https://www.vanguardia.com/binrepository/716x1074/0c176/716d477/none/12204/YTCD/maquillaje-aesthetic-1_8313822_20230518103443.jpg" alt="">
                    <h2>Ojos</h2>
                    <a href="tienda.html">comprar ahora</a>
                </article>
                <article>
                    <img src="https://images.ctfassets.net/wlke2cbybljx/2kjIm7GoqUXt4BZdVWPkpn/79c98dc044bb533fb821496371886594/031_220002_LOVEGASM_EM_GLOSS_F_PINKGASM_LIPS_JB_2203___1_.jpg?w=500&h=500&fit=fill&fm=jpg&bg=" alt="">
                    <h2>Labios</h2>
                    <a href="tienda.html">comprar ahora</a>
                </article>
            </section>
            <section class="botones">
                <div class="fila">
                    <button onclick="window.location.href='https://www.sephora.es/marcas-de-a-a-z/'">
                        <img src="https://www.sephora.es/on/demandware.static/-/Sites-siteCatalog_Sephora_ES/es_ES/dwfb05970b/dior_brand.jpg" alt="Imagen 1">
                    </button>
                    <button onclick="window.location.href='https://www.sephora.es/marcas-de-a-a-z/'">
                        <img src="https://www.sephora.es/on/demandware.static/-/Sites-siteCatalog_Sephora_ES/default/dwd8acdca9/all_brands/TOOFACED_LOGO_1_copie.jpg" alt="Imagen 2">
                    </button>
                    <button onclick="window.location.href='https://www.sephora.es/marcas-de-a-a-z/'">
                        <img src="https://www.sephora.es/on/demandware.static/-/Sites-siteCatalog_Sephora_ES/default/dwc0f88d4e/all_brands/URBAN_DECAY_LOGO_copie.jpg" alt="Imagen 3">
                    </button>
                    <button onclick="window.location.href='https://www.sephora.es/marcas-de-a-a-z/'">
                        <img src="https://www.sephora.es/on/demandware.static/-/Sites-siteCatalog_Sephora_ES/es_ES/dw71049e5f/dsk-2004-es-logomarque-YSL.jpg" alt="Imagen 4">
                    </button>
                    <button onclick="window.location.href='https://www.sephora.es/marcas-de-a-a-z/'">
                        <img src="https://www.sephora.es/on/demandware.static/-/Sites-siteCatalog_Sephora_ES/es_ES/dw44f2ef4e/RAREBEAUTY_BANNER1.jpg" alt="Imagen 5">
                    </button>
                    <button onclick="window.location.href='https://www.sephora.es/marcas-de-a-a-z/'">
                        <img src="https://www.sephora.es/on/demandware.static/-/Sites-siteCatalog_Sephora_ES/default/dw24dc5c09/all_brands/BENEFIT_LOGO_copie.jpg" alt="Imagen 6">
                    </button>
                </div>

                <div class="container-items">
			<div class="item">
				<figure>
					<img
						src="https://media.vogue.es/photos/620b75c76f03d6dda53292df/master/w_320%2Cc_limit/Captura%2520de%2520pantalla%25202022-02-15%2520a%2520las%252010.42.41.png"
						alt="producto"
					/>
				</figure>
				<div class="info-product">
					<h2>Base De Maquillaje</h2>
					<p class="price">$45</p>
					<button>Añadir al carrito</button>
				</div>
			</div>
			<div class="item">
				<figure>
					<img
						src="https://e00-telva.uecdn.es/assets/multimedia/imagenes/2020/03/03/15832556250727.png"
						alt="producto"
					/>
				</figure>
				<div class="info-product">
					<h2>Concealer</h2>
					<p class="price">$27</p>
					<button>Añadir al carrito</button>
				</div>
			</div>
			<div class="item">
				<figure>
					<img
						src="https://e00-telva.uecdn.es/assets/multimedia/imagenes/2021/04/26/16194330325660.png"
						alt="producto"
					/>
				</figure>
				<div class="info-product">
					<h2>Máscara De Pestañas</h2>
					<p class="price">$18</p>
					<button>Añadir al carrito</button>
				</div>
			</div>
			<div class="item">
				<figure>
					<img
						src="https://www.maquillalia.com/images/productos/nyx-professional-makeup-gel-fijador-de-cejas-bare-with-me-1-47463.jpeg"
						alt="producto"
					/>
				</figure>
				<div class="info-product">
					<h2>Fijador De Cejas</h2>
					<p class="price">$7</p>
					<button>Añadir al carrito</button>
				</div>
			</div>
			<div class="item">
				<figure>
					<img
						src="https://montoccosmetictools.com/wp-content/uploads/2023/10/click-gloss-tono-20.jpg"
						alt="producto"
					/>
				</figure>
				<div class="info-product">
					<h2>Gloss</h2>
					<p class="price">$35</p>
					<button>Añadir al carrito</button>
				</div>
			</div>
		    <div class="item">
				<figure>
					<img
						src="https://i8.amplience.net/i/Cosnova/3016082"
						alt="producto"
					/>
				</figure>
				<div class="info-product">
					<h2>Perfilador de labios</h2>
					<p class="price">$9</p>
					<button>Añadir al carrito</button>
				</div>
			</div>

            </section>
            <div class="skincare">
                <div class="textomoverse2">
                    <h1 id="titulomov2">Lo mejor en skincare</h1>
                    <img src="https://hotbook.mx/wp-content/uploads/2020/04/beauty-products-portada.jpg" alt="">
                    
                    <a href="#">Comprar ahora</a>
                </div>
            </div>
            <div class="titulofavfoot">
                <h2>Los favoritos de nuestra tienda</h2>
            </div>
            
            <section class="favfoot">
                <article>
                    <img src="https://blogscdn.thehut.net/app/uploads/sites/22/2021/02/1200x672-Blog-256073423-CA-LF-August-Batch-shot-16_1200x672_acf_cropped_1612282972_1200x672_acf_cropped.jpg" alt="">
                    <h2>Bases de larga duración</h2>
                    <a href="tienda.html">comprar ahora</a>
                </article>
                <article>
                    <img src="https://www.marie-claire.es/files/article_social_75/uploads/2023/01/10/63bc9cf7eefbf.jpeg" alt="">
                    <h2>Maquillaje de ojos waterproof</h2>
                    <a href="tienda.html">comprar ahora</a>
                </article>
                <article>
                    <img src="https://okdiario.com/img/2022/03/04/labial-que-dura-24-horas-no-es-una-utopia-990x556.jpg" alt="">
                    <h2>Labiales resistentes las 24h</h2>
                    <a href="tienda.html">comprar ahora</a>
                </article>
            </section>
            <section class="botones">
                <div class="fila">
                    <button onclick="window.location.href='https://www.footlocker.es/es/category/brands/new-balance.html'">
                        <img src="https://images.footlocker.com/content/dam/final/footlockereurope/Online_activations/fl-campaign/2023/2023_05_09_fl_omn_certifiedclassics/05_final_output_files/ecom/category/2023_05_09_FL_OMN_CertifiedClassics_MEN_EN_HP_Button_800x800.jpg" alt="Imagen 1">
                    </button>
                    <button onclick="window.location.href='https://www.footlocker.es/es/category/brands/adidas.html'">
                        <img src="https://images.footlocker.com/content/dam/final/footlockereurope/Online_activations/fl-campaign/2023/2023_05_09_fl_omn_certifiedclassics/05_final_output_files/ecom/category/2023_05_09_FL_OMN_CertifiedClassics_HP_Button_GENDER_Women_A_800x800.jpg" alt="Imagen 2">
                    </button>
                    <button onclick="window.location.href='https://www.footlocker.es/es/category/brands/nike.html'">
                        <img src="https://images.footlocker.com/content/dam/final/footlockereurope/Online_activations/fl-campaign/2023/2023_05_09_fl_omn_certifiedclassics/05_final_output_files/ecom/category/2023_05_09_FL_OMN_CertifiedClassics_KIDS_EN_HP_Button_800x800.jpg" alt="Imagen 3">
                    </button>
                    <button onclick="window.location.href='https://www.footlocker.es/es/category/brands/converse.html'">
                        <img src="https://images.footlocker.com/content/dam/final/footlockereurope/Online_activations/fl-campaign/2023/2023_05_09_fl_omn_certifiedclassics/05_final_output_files/ecom/category/2023_05_09_FL_OMN_CertifiedClassics_NEWIN_EN_HP_Button_800x800.jpg" alt="Imagen 4">
                    </button>
                    <button onclick="window.location.href='https://www.footlocker.es/es/category/brands/asics.html'">
                        <img src="https://images.footlocker.com/content/dam/final/footlockereurope/Online_activations/fl-campaign/2023/2023_05_09_fl_omn_certifiedclassics/05_final_output_files/ecom/category/2023_05_09_FL_OMN_CertifiedClassics_HP_Button_BESTSELLERS_GIF_800x800.gif" alt="Imagen 5">
                    </button>
                    <button onclick="window.location.href='https://www.footlocker.es/es/brands.html'">
                        <img src="https://images.footlocker.com/content/dam/final/footlockereurope/Online_activations/fl-campaign/2023/2023_05_09_fl_omn_certifiedclassics/05_final_output_files/ecom/category/2023_05_09_FL_OMN_CertifiedClassics_LAUNCHES_EN_HP_Button_800x800.jpg" alt="Imagen 6">
                    </button>
                </div>
            </section>
        </main> 
        <footer>
            <div>
                <a href="">politica de privacidad</a>
                <a href="">cookies</a>
                <a href="">contacto</a>
            </div>
            <div>
                <a href=""><img src="" alt=""></a>
            </div>
            <div>
                <h4>Contáctanos</h4>
                <p>Calle consuegra, 3</p>
                <p>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3035.020748125787!2d-3.6765456999999997!3d40.474806!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd4229475fc7e749%3A0x71a6fb4707b13a23!2sC.%20Consuegra%2C%203%2C%2028036%20Madrid!5e0!3m2!1ses!2ses!4v1695728542442!5m2!1ses!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>" frameborder="0"></iframe>
                </p>
            </div>
        </footer>
    </body>
</html>
<footer class="site-footer">
        <div class="footer-content">
            <div class="footer-photo">
                <img src="imagenes/asistentefinal.png" alt="Descripción de la foto">
            </div>
            <div class="footer-links">
                <a href="ruta-a-soporte.html">Soporte</a>
                <a href="ruta-a-faq.html">Preguntas Frecuentes</a>
                <a href="ruta-a-terminos.html">Términos de Servicio</a>
                <a href="ruta-a-privacidad.html">Política de Privacidad</a>
                <a href="contacto.html">Contacto</a>
            </div>
        </div>
    </footer>
    <main>
    <div class="botones-container">
        <p><a class="button" href="php/nuevo.php">Crear</a></p>
    </div>
    <div class="comentario-contenedor">
    <?php foreach ($miConsulta as $clave => $valor): ?>
        <div class="comentario-bloque">
            <div class="comentario-nombre"><?= htmlspecialchars($valor['nombre']); ?></div>
            <div class="comentario-texto"><?= htmlspecialchars($valor['caracteristicas']); ?></div>
            <a class="button" href="php/modificar.php?idproductos=<?= $valor['idproductos'] ?>">Modificar</a>
            <a class="button" href="php/borrar.php?idproductos=<?= $valor['idproductos'] ?>">Borrar</a>
        </div>
    <?php endforeach; ?>
    </div>